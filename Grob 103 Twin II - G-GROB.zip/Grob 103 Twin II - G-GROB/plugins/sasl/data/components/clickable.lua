
function draw(self)
    if showClickableAreas then
        drawFrame(0, 0, 100, 100)
    end
end

