Scriptable Avionics Simulation Library
Copyright (c) 2008-2009 Alexander Babichev

This software distributed under terms of GPL 3.0 license.

