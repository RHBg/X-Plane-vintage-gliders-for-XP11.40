
-- for debugging
function draw(self)
    drawFrame(0, 0, 100, 100)
end

